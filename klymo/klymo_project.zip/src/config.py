import ee

# Earth Engine Project Config
# Make sure to run `earthengine authenticate` in your terminal first.
EE_PROJECT_ID = 'nimble-anagram-486108-e1' # Updated with valid Project ID

# Data Config
SENTINEL_BANDS = ['B2', 'B3', 'B4'] # RGB
SCALE_LR = 10 # Sentinel-2 is 10m
SCALE_HR = 1.25 # Target resolution (approx 8x upscaling)

# Region of Interest (Example: Urban area in US for NAIP overlap)
# San Francisco
ROI_COORDS = [[-122.43, 37.75], [-122.41, 37.75], [-122.41, 37.77], [-122.43, 37.77]]
