import torch
import numpy as np
import cv2
from PIL import Image
from model import Generator
from utils import normalize_s2, tile_image, stitch_image
import os

DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")

class Upscaler:
    def __init__(self, model_path=None):
        self.model = Generator(in_nc=3, out_nc=3, upscale=4).to(DEVICE)
        if model_path and os.path.exists(model_path):
            self.model.load_state_dict(torch.load(model_path, map_location=DEVICE))
            print(f"Loaded model from {model_path}")
        else:
            print("Warning: No model loaded, using random weights (for demo)")
        self.model.eval()

    def predict(self, image_path):
        """
        Runs inference on an image path.
        Returns: Tuple(Original Image (PIL), Upscaled Image (PIL))
        """
        input_img = Image.open(image_path).convert('RGB')
        img_np = np.array(input_img)
        
        # Simple Logic: Resize input to simulate super-resolution on a larger canvas
        # Or if input is small patch, just run it.
        
        # Normalize
        # If Sentinel-2 is 16-bit, we treat it differently.
        # Assuming input here is a saved PNG/JPG visual for the demo
        img_norm = img_np.astype(np.float32) / 255.0
        
        img_tensor = torch.from_numpy(img_norm).permute(2, 0, 1).unsqueeze(0).float().to(DEVICE)
        
        with torch.no_grad():
            output = self.model(img_tensor)
            
        output = output.squeeze(0).permute(1, 2, 0).cpu().numpy()
        output = np.clip(output, 0, 1)
        output_pil = Image.fromarray((output * 255).astype(np.uint8))
        
        return input_img, output_pil

if __name__ == "__main__":
    # Test
    upscaler = Upscaler()
    # Dummy image
    dummy = np.random.randint(0, 255, (64, 64, 3), dtype=np.uint8)
    Image.fromarray(dummy).save("dummy_lr.png")
    
    lr, sr = upscaler.predict("dummy_lr.png")
    sr.save("dummy_sr.png")
    print("Inference completed: dummy_sr.png")
